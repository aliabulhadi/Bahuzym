<?php
include 'db.php';
session_start();

$error_message = "";
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $role     = $_POST['role']; // 'student' أو 'instructor'

    if (empty($fullname) || empty($email) || empty($password) || empty($role)) {
        $error_message = "❌ يرجى ملء جميع الحقول.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "❌ البريد الإلكتروني غير صحيح.";
    } else {
        // التحقق من عدم تكرار البريد
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $error_message = "❌ هذا البريد الإلكتروني مسجل بالفعل!";
        } else {
            // تشفير كلمة المرور
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt_insert = $pdo->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)");
            if ($stmt_insert->execute([$fullname, $email, $hashed_password, $role])) {
                $success_message = "🎉 تم إنشاء الحساب بنجاح! يمكنك الآن الانتقال لصفحة تسجيل الدخول.";
            } else {
                $error_message = "❌ حدث خطأ غير متوقع، حاول مرة أخرى.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إنشاء حساب جديد</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="auth-container">
        <div class="auth-box">
            <h2>إنشاء حساب جديد 🎓</h2>
            
            <?php if(!empty($error_message)): ?>
                <div style="background-color: #fee2e2; color: #b91c1c; padding: 10px; border-radius: 5px; margin-bottom: 1rem; text-align: center;"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <?php if(!empty($success_message)): ?>
                <div style="background-color: #d1fae5; color: #065f46; padding: 10px; border-radius: 5px; margin-bottom: 1rem; text-align: center;"><?php echo $success_message; ?></div>
            <?php endif; ?>

            <form action="register.php" method="post">
                <div class="input-group">
                    <label>الاسم الكامل</label>
                    <input type="text" name="fullname" placeholder="أدخل اسمك الثلاثي" required>
                </div>
                <div class="input-group">
                    <label>البريد الإلكتروني</label>
                    <input type="email" name="email" placeholder="example@mail.com" required>
                </div>
                <div class="input-group">
                    <label>كلمة المرور</label>
                    <input type="password" name="password" placeholder="********" required>
                </div>
                <div class="input-group">
                    <label>نوع الحساب</label>
                    <select name="role" required>
                        <option value="student">طالب (أريد التعلم)</option>
                        <option value="instructor">مدرس (أريد رفع كورسات)</option>
                    </select>
                </div>
                <button type="submit" class="btn-auth">تسجيل الحساب</button>
            </form>
            <p class="auth-footer">لديك حساب بالفعل؟ <a href="login.php">تسجيل الدخول من هنا</a></p>
        </div>
    </main>
</body>
</html>