<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'instructor') {
    header("Location: login.php");
    exit();
}

$course_id = intval($_GET['id']);
$instructor_id = $_SESSION['user_id'];
$error_message = ""; $success_message = "";

$stmt_check = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND instructor_id = ?");
$stmt_check->execute([$course_id, $instructor_id]);
$course = $stmt_check->fetch();
if (!$course) { die("❌ غير مسموح لك بإدارة هذا الكورس."); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_lecture'])) {
    $lecture_title = trim($_POST['lecture_title']);
    $video_file    = $_FILES['lecture_video'];

    $stmt_order = $pdo->prepare("SELECT MAX(order_number) FROM lectures WHERE course_id = ?");
    $stmt_order->execute([$course_id]);
    $next_order = intval($stmt_order->fetchColumn()) + 1;

    $videos_dir = 'uploads/videos/';
    $video_mime = mime_content_type($video_file['tmp_name']);
    
    if ($video_file['size'] <= 50 * 1024 * 1024 && in_array($video_mime, ['video/mp4', 'video/webm'])) {
        $video_name = uniqid('video_', true) . '.' . pathinfo($video_file['name'], PATHINFO_EXTENSION);
        $video_target = $videos_dir . $video_name;
        if (move_uploaded_file($video_file['tmp_name'], $video_target)) {
            $stmt_ins = $pdo->prepare("INSERT INTO lectures (course_id, title, video_url, order_number) VALUES (?, ?, ?, ?)");
            $stmt_ins->execute([$course_id, $lecture_title, $video_target, $next_order]);
            $success_message = "▶️ تم إضافة المحاضرة ($next_order) بنجاح!";
        }
    } else { $error_message = "❌ عذراً، حجم الفيديو كبير جداً أو صيغته غير مدعومة."; }
}

$stmt_lectures = $pdo->prepare("SELECT * FROM lectures WHERE course_id = ? ORDER BY order_number ASC");
$stmt_lectures->execute([$course_id]);
$lectures = $stmt_lectures->fetchAll();

$stmt_sales = $pdo->prepare("SELECT e.price_paid, e.enrolled_at, u.fullname as student_name, u.email as student_email FROM enrollments e JOIN users u ON e.student_id = u.id WHERE e.course_id = ? ORDER BY e.enrolled_at DESC");
$stmt_sales->execute([$course_id]);
$sales = $stmt_sales->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة وتطوير الكورس</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">
    <main class="dashboard-content" style="max-width:1100px; margin:2rem auto; padding:0 1rem;">
        <h3>🛠️ كورس: <?php echo htmlspecialchars($course['title']); ?></h3>
        <?php if(!empty($success_message)): ?><div style="background:#d1fae5; padding:10px; color:#065f46; border-radius:5px;"><?php echo $success_message; ?></div><?php endif; ?>
        
        <div style="display:flex; gap:2rem; margin-top:1.5rem; flex-wrap:wrap;">
            <form action="manage-course.php?id=<?php echo $course_id; ?>" method="post" enctype="multipart/form-data" style="background:#fff; padding:1.5rem; border-radius:8px; flex:1; min-width:300px;">
                <h4>➕ إضافة درس تكميلي للمنهج</h4>
                <div class="input-group"><label>عنوان الدرس</label><input type="text" name="lecture_title" required></div>
                <div class="input-group"><label>ملف الفيديو</label><input type="file" name="lecture_video" accept="video/*" required></div>
                <button type="submit" name="add_lecture" class="btn-add-course" style="width:100%;">رفع وحفظ الدرس</button>
            </form>
            
            <div style="background:#fff; padding:1.5rem; border-radius:8px; flex:1; min-width:300px; max-height:300px; overflow-y:auto;">
                <h4>📚 الدروس المرفوعة حالياً</h4>
                <?php foreach($lectures as $lec): ?>
                    <div style="padding:8px; border-bottom:1px solid #eee;">📄 درس <?php echo $lec['order_number']; ?>: <?php echo htmlspecialchars($lec['title']); ?></div>
                <?php endforeach; ?>
            </div>
        </div>

        <section class="dash-table-section" style="margin-top:2rem;">
            <div class="table-header"><h3>💰 سجل مبيعات الطلاب لهذا المساق</h3></div>
            <table class="dash-table">
                <thead><tr><th>اسم الطالب</th><th>البريد</th><th>تاريخ الشراء</th><th>المبلغ</th></tr></thead>
                <tbody>
                    <?php if(count($sales) > 0): foreach($sales as $sale): ?>
                        <tr><td><?php echo htmlspecialchars($sale['student_name']); ?></td><td><?php echo htmlspecialchars($sale['student_email']); ?></td><td><?php echo $sale['enrolled_at']; ?></td><td style="color:#10b981; font-weight:bold;">$<?php echo number_format($sale['price_paid'],2); ?></td></tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="4" style="text-align:center; padding:1.5rem;">لا توجد مبيعات بعد.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>