<?php ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>منصتنا التعليمية | من نحن</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="header">
        <p class="brand-name">منصتنا التعليمية</p>
        <h1>تعلم مهارات المستقبل اليوم</h1>
        <h3>أكتشف الاف الكورسات التي يقدمها أفضل الخبراء في مجالات البرمجة و التصميم و أدارة الأعمال</h3>
    </header>

    <nav class="lonk">
        <a href="index.php">الرئيسية</a>
        <a href="courses.php">معلومات الكورسات</a>
        <a href="contact.php">تواصل بنا</a>
        <a href="about.php">من نحن</a>
        <a href="login.php">صفحة التسجيل</a>
        
    </nav>

    <main class="about-container">
        
        <section class="about-hero">
            <h2>حول منصتنا التعليمية</h2>
            <p>نحن منصة تعليمية متكاملة وسوق رقمي يهدف إلى تمكين العقول وتسهيل مشاركة المعرفة. نربط بين أفضل المدرسين والخبراء وبين الطلاب الطموحين لتوفير تجربة تعليمية مرنة وذكية من الصفر وحتى الاحتراف.</p>
        </section>

        <section class="vision-mission-box">
            <div class="vision-item">
                <h3>👁️ رؤيتنا</h3>
                <p>أن نكون المنصة الرائدة والأولى في تقديم التعليم الذكي والحلول البرمجية والتقنية، وإتاحة الفرصة لكل صاحب مهارة أن يشاركها مع العالم ويحقق منها عائداً مالياً مستداماً.</p>
            </div>
            <div class="vision-item">
                <h3>🎯 رسالتنا</h3>
                <p>تذليل العقبات أمام الطلاب للوصول إلى محتوى تعليمي عالي الجودة بأسعار مناسبة، وتوفير بيئة برمجية قوية للمدرسين لإدارة كورساتهم وطلابهم بكل سهولة وأمان.</p>
            </div>
        </section>

        <section class="why-us">
            <h2 class="section-title">ماذا نقدم في المنصة؟</h2>
            <div class="cont"> <article class="course-card about-card">
                    <div class="about-card-icon">🎓</div>
                    <div class="course-content">
                        <h3 class="course-title">للطلاب: تعلم مرن ومستمر</h3>
                        <p class="instructor-name">وصول مدى الحياة للكورسات، اختبارات دورية وتطبيقات عملية، وتواصل مباشر مع المدرسين عبر نظام المناقشات.</p>
                    </div>
                </article>

                <article class="course-card about-card">
                    <div class="about-card-icon">💼</div>
                    <div class="course-content">
                        <h3 class="course-title">للمدرسين: سوق عمل خاص بك</h3>
                        <p class="instructor-name">أدوات متكاملة لرفع وإدارة محتوى الكورسات، لوحة تحكم لمتابعة الأرباح والمبيعات، ونظام سحب مالي مرن.</p>
                    </div>
                </article>

                <article class="course-card about-card">
                    <div class="about-card-icon">🛡️</div>
                    <div class="course-content">
                        <h3 class="course-title">نظام آمن وحماية قوية</h3>
                        <p class="instructor-name">بنية برمجية مبنية بأعلى معايير الأمان لحماية بيانات المستخدمين، محتوى الكورسات، والعمليات المالية داخل المنصة.</p>
                    </div>
                </article>

            </div>
        </section>

    </main>

</body>
</html>
