<?php
include 'db.php';
session_start();

// 1. حماية الصفحة: التأكد من أن المستخدم مسجل دخول ورتبته admin حصراً
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$success_message = "";

// 2. معالجة حذف رسائل تواصل بنا عند الضغط على زر الحذف
if (isset($_GET['delete_msg'])) {
    $msg_id = intval($_GET['delete_msg']);
    $stmt_del = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
    if ($stmt_del->execute([$msg_id])) {
        $success_message = "🗑️ تم حذف الرسالة بنجاح.";
    }
}

// 3. جلب الإحصائيات العامة للمنصة
try {
    // عدد الطلاب
    $count_students = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
    
    // عدد المدرسين
    $count_instructors = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'instructor'")->fetchColumn();
    
    // إجمالي عدد الكورسات
    $count_courses = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
    
    // إجمالي الأرباح المالية الكلية للموقع
    $total_earnings = $pdo->query("SELECT SUM(price_paid) FROM enrollments")->fetchColumn() ?? 0;

    // 4. جلب رسائل تواصل بنا المعروضة في اللوحة
    $stmt_messages = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
    $messages = $stmt_messages->fetchAll();

} catch (Exception $e) {
    die("خطأ في النظام: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم العليا للمدير العام</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">

    <div class="dashboard-wrapper">
        
        <!-- الشريط الجانبي للمدير -->
        <aside class="sidebar" style="background-color: #0f172a;">
            <div class="sidebar-brand"><h2 style="color: #38bdf8;">⚙️ الإدارة العليا</h2></div>
            <ul class="sidebar-menu">
                <li><a href="admin-dashboard.php" class="active">📊 إحصائيات عامة</a></li>
                <li><a href="index.php">🌐 واجهة الموقع</a></li>
                <li><a href="logout.php" style="color: #f87171;">🚪 تسجيل الخروج</a></li>
            </ul>
        </aside>

        <!-- المحتوى الرئيسي للمدير -->
        <main class="dashboard-content">
            <header class="dash-header">
                <div>
                    <h3>مرحباً بك في لوحة الإدارة العليا للـ Admin 👋</h3>
                    <p style="color: #64748b; font-size: 0.9rem;">مراقبة الأداء المالي، أعداد المستخدمين، والرسائل الواردة.</p>
                </div>
            </header>

            <!-- صناديق الإحصائيات (Cards) -->
            <section class="admin-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                
                <div style="background: #fff; padding: 1.5rem; border-radius: 12px; border-right: 5px solid #3b82f6; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                    <span style="color: #64748b; font-size: 0.85rem; font-weight: bold;">👥 إجمالي الطلاب</span>
                    <h2 style="color: #1e293b; margin: 0.5rem 0 0 0; font-size: 2rem;"><?php echo $count_students; ?> طالب</h2>
                </div>

                <div style="background: #fff; padding: 1.5rem; border-radius: 12px; border-right: 5px solid #a855f7; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                    <span style="color: #64748b; font-size: 0.85rem; font-weight: bold;">👨‍🏫 إجمالي المدرسين</span>
                    <h2 style="color: #1e293b; margin: 0.5rem 0 0 0; font-size: 2rem;"><?php echo $count_instructors; ?> مدرس</h2>
                </div>

                <div style="background: #fff; padding: 1.5rem; border-radius: 12px; border-right: 5px solid #eab308; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                    <span style="color: #64748b; font-size: 0.85rem; font-weight: bold;">📚 المساقات التعليمية</span>
                    <h2 style="color: #1e293b; margin: 0.5rem 0 0 0; font-size: 2rem;"><?php echo $count_courses; ?> كورس</h2>
                </div>

                <div style="background: #fff; padding: 1.5rem; border-radius: 12px; border-right: 5px solid #10b981; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                    <span style="color: #64748b; font-size: 0.85rem; font-weight: bold;">💰 دخل المنصة الكلي</span>
                    <h2 style="color: #10b981; margin: 0.5rem 0 0 0; font-size: 2rem;">$<?php echo number_format($total_earnings, 2); ?></h2>
                </div>

            </section>

            <?php if(!empty($success_message)): ?>
                <div style="background-color: #d1fae5; color: #065f46; padding: 12px; border-radius: 8px; margin-bottom: 1.5rem; text-align: center; font-weight: bold;"><?php echo $success_message; ?></div>
            <?php endif; ?>

            <!-- قسم إدارة ورسائل تواصل بنا -->
            <section class="dash-table-section">
                <div class="table-header" style="background-color: #1e293b;">
                    <h3 style="color: #fff; margin: 0;">✉️ الرسائل والاستفسارات الواردة</h3>
                </div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr>
                                <th>اسم المرسل</th>
                                <th>البريد الإلكتروني</th>
                                <th>الموضوع</th>
                                <th>نص الرسالة</th>
                                <th>تاريخ الإرسال</th>
                                <th>الإجراء</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($messages) > 0): ?>
                                <?php foreach($messages as $msg): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($msg['fullname']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                        <td><span style="color: #0284c7; font-weight: bold;"><?php echo htmlspecialchars($msg['subject']); ?></span></td>
                                        <td style="max-width: 300px; white-space: pre-line; font-size: 0.9rem; color: #475569;"><?php echo htmlspecialchars($msg['message']); ?></td>
                                        <td style="font-size: 0.85rem; color: #64748b;"><?php echo $msg['created_at']; ?></td>
                                        <td>
                                            <a href="admin-dashboard.php?delete_msg=<?php echo $msg['id']; ?>" class="btn-action delete" style="background-color: #ef4444; text-decoration: none;" onclick="return confirm('هل أنت متأكد من حذف هذه الرسالة نهائياً؟');">حذف الرسالة</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 3rem; color: #64748b;">📭 صندوق الوارد فارغ، لا توجد أي رسائل حالياً.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </div>

</body>
</html>