<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'instructor') {
    header("Location: login.php"); exit();
}

$course_id = intval($_GET['id']);
$instructor_id = $_SESSION['user_id'];

try {
    $stmt_check = $pdo->prepare("SELECT cover_image FROM courses WHERE id = ? AND instructor_id = ?");
    $stmt_check->execute([$course_id, $instructor_id]);
    $course = $stmt_check->fetch();

    if (!$course) { die("❌ لا تملك هذه الصلاحية."); }

    $stmt_lectures = $pdo->prepare("SELECT video_url FROM lectures WHERE course_id = ?");
    $stmt_lectures->execute([$course_id]);
    $lectures = $stmt_lectures->fetchAll();

    $pdo->beginTransaction();

    $pdo->prepare("DELETE FROM lectures WHERE course_id = ?")->execute([$course_id]);
    $pdo->prepare("DELETE FROM enrollments WHERE course_id = ?")->execute([$course_id]);
    $pdo->prepare("DELETE FROM courses WHERE id = ? AND instructor_id = ?")->execute([$course_id, $instructor_id]);

    $pdo->commit();

    // مسح الملفات فيزيائياً لتوفير المساحة
    if (file_exists($course['cover_image'])) unlink($course['cover_image']);
    foreach ($lectures as $lec) {
        if (file_exists($lec['video_url'])) unlink($lec['video_url']);
    }

    header("Location: dashboard.php");
    exit();
} catch (Exception $e) {
    $pdo->rollBack();
    die("❌ فشل عملية الحذف: " . $e->getMessage());
}
?>