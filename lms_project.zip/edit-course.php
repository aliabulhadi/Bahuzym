<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'instructor') {
    header("Location: login.php"); exit();
}

$course_id = intval($_GET['id']);
$instructor_id = $_SESSION['user_id'];
$error_message = ""; $success_message = "";

$stmt_fetch = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND instructor_id = ?");
$stmt_fetch->execute([$course_id, $instructor_id]);
$course = $stmt_fetch->fetch();
if (!$course) { die("❌ الكورس غير موجود."); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $category = $_POST['category'];
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $status = ($_POST['status'] === 'publish') ? 'published' : 'draft';
    $cover_target = $course['cover_image'];

    if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
        $cover_file = $_FILES['cover_image'];
        $cover_mime = mime_content_type($cover_file['tmp_name']);
        
        if (in_array($cover_mime, ['image/jpeg', 'image/png', 'image/webp']) && $cover_file['size'] <= 2*1024*1024) {
            $new_name = uniqid('cover_edit_', true) . '.' . pathinfo($cover_file['name'], PATHINFO_EXTENSION);
            $new_target = 'uploads/covers/' . $new_name;
            if (move_uploaded_file($cover_file['tmp_name'], $new_target)) {
                if (file_exists($course['cover_image'])) unlink($course['cover_image']);
                $cover_target = $new_target;
            }
        } else { $error_message = "❌ غلاف غير صالح."; }
    }

    if (empty($error_message)) {
        $stmt_up = $pdo->prepare("UPDATE courses SET title=?, category=?, description=?, price=?, cover_image=?, status=? WHERE id=? AND instructor_id=?");
        if ($stmt_up->execute([$title, $category, $description, $price, $cover_target, $status, $course_id, $instructor_id])) {
            $success_message = "💾 تم حفظ البيانات المحدثة!";
            $course['title'] = $title; $course['cover_image'] = $cover_target; // تحديث الواجهة فورياً
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات الكورس</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">
    <main style="max-width:700px; margin:3rem auto; background:#fff; padding:2rem; border-radius:10px;">
        <h3>✏️ تعديل بيانات الكورس</h3>
        <?php if(!empty($success_message)): ?><div style="background:#d1fae5; color:#065f46; padding:10px;"><?php echo $success_message; ?></div><?php endif; ?>
        <form action="edit-course.php?id=<?php echo $course_id; ?>" method="post" enctype="multipart/form-data" style="display:flex; flex-direction:column; gap:1rem; margin-top:1rem;">
            <div class="input-group"><label>العنوان</label><input type="text" name="title" value="<?php echo htmlspecialchars($course['title']); ?>" required></div>
            <div class="input-group"><label>الوصف</label><textarea name="description" rows="4" required><?php echo htmlspecialchars($course['description']); ?></textarea></div>
            <div class="input-group"><label>السعر ($)</label><input type="number" name="price" step="0.01" value="<?php echo $course['price']; ?>" required></div>
            <div class="input-group"><label>المجال</label><select name="category"><option value="programming" <?php if($course['category']=='programming') echo 'selected'; ?>>برمجة</option></select></div>
            <div class="input-group"><label>تحديث صورة الغلاف (اختياري)</label><input type="file" name="cover_image"></div>
            <button type="submit" name="status" value="publish" class="btn-add-course">💾 حفظ التحديثات</button>
        </form>
    </main>
</body>
</html>