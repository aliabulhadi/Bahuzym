<?php
include 'db.php';
session_start();

$error_message = ""; $success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $fullname = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $subject  = trim($_POST['subject']);
    $message  = trim($_POST['message']);

    if (empty($fullname) || empty($email) || empty($subject) || empty($message)) {
        $error_message = "❌ يرجى ملء الحقول.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "❌ بريد غير صحيح.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO contact_messages (fullname, email, subject, message) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$fullname, $email, $subject, $message])) {
            $success_message = "🚀 تم استلام رسالتك وحفظها بنجاح!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تواصل بنا</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <p class="brand-name">منصتنا التعليمية</p>
        <h1>تعلم مهارات المستقبل اليوم</h1>
        <h3>أكتشف الاف الكورسات التي يقدمها أفضل الخبراء في مجالات البرمجة و التصميم و أدارة الأعمال</h3>
    </header>
<nav class="lonk">
        <a href="index.php">الرئيسية</a>
        <a href="courses.php">معلومات الكورسات</a>
        <a href="contact.php">تواصل بنا</a>
        <a href="about.php">من نحن</a>
        <a href="login.php">صفحة التسجيل</a>
</nav>
    <main class="auth-container" style="max-width: 600px; margin: 3rem auto;">
        <div class="auth-box" style="width:100%;">
            <h2>تواصل معنا ✉️</h2>
            <?php if(!empty($success_message)): ?><div style="background:#d1fae5; color:#065f46; padding:10px;"><?php echo $success_message; ?></div><?php endif; ?>
            <form action="contact.php" method="post" style="margin-top:1rem;">
                <div class="input-group"><label>الاسم</label><input type="text" name="fullname" required></div>
                <div class="input-group"><label>البريد</label><input type="email" name="email" required></div>
                <div class="input-group"><label>الموضوع</label><input type="text" name="subject" required></div>
                <div class="input-group"><label>الرسالة</label><textarea name="message" rows="4" required></textarea></div>
                <button type="submit" name="send_message" class="btn-auth">إرسال الرسالة</button>
            </form>
        </div>
    </main>
</body>
</html>