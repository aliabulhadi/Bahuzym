<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $course_id = intval($_POST['course_id']);
    $student_id = $_SESSION['user_id'];
    
    if ($_SESSION['user_role'] === 'instructor') {
        die("❌ المدرسون لا يمكنهم الاشتراك في الكورسات كطلاب.");
    }

    try {
        $stmt_course = $pdo->prepare("SELECT price, status FROM courses WHERE id = ?");
        $stmt_course->execute([$course_id]);
        $course = $stmt_course->fetch();

        if (!$course || $course['status'] !== 'published') {
            die("❌ الكورس غير متاح للاشتراك.");
        }

        $price_paid = $course['price'];

        // منع تكرار الاشتراك بنفس الكورس للغرض الأمني
        $stmt_check = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
        $stmt_check->execute([$student_id, $course_id]);

        if ($stmt_check->rowCount() > 0) {
            header("Location: course-details.php?id=" . $course_id);
            exit();
        }

        $stmt_enroll = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, price_paid) VALUES (?, ?, ?)");
        if ($stmt_enroll->execute([$student_id, $course_id, $price_paid])) {
            header("Location: course-details.php?id=" . $course_id);
            exit();
        }
    } catch (Exception $e) {
        die("خطأ نظام: " . $e->getMessage());
    }
} else {
    header("Location: index.php");
    exit();
}
?>