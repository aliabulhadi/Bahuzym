<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'instructor') {
    header("Location: login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];

// جلب كورسات المدرس
$stmt = $pdo->prepare("SELECT * FROM courses WHERE instructor_id = ? ORDER BY created_at DESC");
$stmt->execute([$instructor_id]);
$my_courses = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم المدرس</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">
    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <div class="sidebar-brand"><h2>لوحة المدرس</h2></div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php" class="active">📊 اللوحة الرئيسية</a></li>
                <li><a href="add-course.php">➕ رفع كورس جديد</a></li>
                <li><a href="logout.php">🚪 تسجيل الخروج</a></li>
            </ul>
        </aside>

        <main class="dashboard-content">
            <header class="dash-header">
                <h3>مرحباً بك يا أستاذ: <?php echo htmlspecialchars($_SESSION['user_name']); ?> 👋</h3>
                <button class="btn-add-course" onclick="window.location.href='add-course.php'">➕ إنشاء كورس جديد</button>
            </header>

            <section class="dash-table-section">
                <div class="table-header"><h3>📚 مساقاتك التعليمية الحالية</h3></div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr>
                                <th>غلاف الكورس</th>
                                <th>عنوان الكورس</th>
                                <th>السعر</th>
                                <th>الحالة</th>
                                <th>الإجراءات والتحكم</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($my_courses) > 0): ?>
                                <?php foreach($my_courses as $course): ?>
                                    <tr>
                                        <td><img src="<?php echo $course['cover_image']; ?>" style="width:80px; height:50px; object-fit:cover; border-radius:4px;"></td>
                                        <td><strong><?php echo htmlspecialchars($course['title']); ?></strong></td>
                                        <td>$<?php echo number_format($course['price'], 2); ?></td>
                                        <td><span class="status-badge <?php echo ($course['status'] === 'published') ? 'active' : 'draft'; ?>"><?php echo ($course['status'] === 'published') ? 'منشور' : 'مسودة'; ?></span></td>
                                        <td>
                                            <a href="edit-course.php?id=<?php echo $course['id']; ?>" class="btn-action edit" style="background:#f59e0b; text-decoration:none;">✏️ تعديل البيانات</a>
                                            <a href="manage-course.php?id=<?php echo $course['id']; ?>" class="btn-action edit" style="background:#0055a5; text-decoration:none;">📚 إدارة المنهج والأرباح</a>
                                            <a href="delete-course.php?id=<?php echo $course['id']; ?>" class="btn-action delete" style="background:#ef4444; text-decoration:none;" onclick="return confirm('⚠️ هل أنت متأكد من حذف الكورس ومحتوياته بالكامل؟');">حذف</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align:center; padding:2rem;">لم تقم برفع أي مساقات تعليمية بعد.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</body>
</html>