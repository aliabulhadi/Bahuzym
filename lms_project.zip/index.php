<?php
include 'db.php';
session_start();

try {
    $stmt = $pdo->prepare("
        SELECT c.id, c.title, c.description, c.price, c.cover_image, u.fullname as instructor_name 
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        WHERE c.status = 'published'
        ORDER BY c.created_at DESC LIMIT 6
    ");
    $stmt->execute();
    $latest_courses = $stmt->fetchAll();
} catch (Exception $e) {
    die("حدث خطأ: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>منصتنا التعليمية | الرئيسية</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <p class="brand-name">منصتنا التعليمية</p>
        <h1>تعلم مهارات المستقبل اليوم</h1>
        <h3>أكتشف الاف الكورسات التي يقدمها أفضل الخبراء في مجالات البرمجة و التصميم و أدارة الأعمال</h3>
    </header>
    <nav class="lonk">
        <a href="index.php">الرئيسية</a>
        <a href="courses.php">معلومات الكورسات</a>
        <a href="contact.php">تواصل بنا</a>
        <a href="about.php">من نحن</a>
        
        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($_SESSION['user_role'] === 'instructor'): ?>
                <a href="dashboard.php" style="color: #0095ff; font-weight: bold;">📊 لوحة التحكم</a>
            <?php else: ?>
                <a href="profile.php" style="color: #0095ff; font-weight: bold;">👤 ملفي الشخصي</a>
            <?php endif; ?>
            <a href="logout.php" style="color: #ef4444;">تسجيل الخروج</a>
        <?php else: ?>
            <a href="login.php">صفحة التسجيل</a>
        <?php endif; ?>
    </nav>

    <section class="welcom">
        <h1>أهلاً بكم في منصتنا التعليمية</h1>
        <p>ابدأ رحلتك الدراسية اليوم مع نخبة من المدرسين والخبراء.</p>
        <button class="btn-primary" onclick="window.location.href='courses.php'">تصفح الدورات المتاحة</button>
    </section>

    <section class="courses-section" style="max-width: 1200px; margin: 3rem auto; padding: 0 1rem;">
        <h2 style="color: #002244; margin-bottom: 2rem; border-right: 5px solid #0055a5; padding-right: 10px;">أحدث الكورسات المتاحة 📚</h2>
        <div class="cont">
            <?php if (count($latest_courses) > 0): ?>
                <?php foreach ($latest_courses as $course): ?>
                    <article class="course-card">
                        <img src="<?php echo htmlspecialchars($course['cover_image']); ?>" style="width: 100%; height: 180px; object-fit: cover; border-radius: 10px 10px 0 0;">
                        <div class="course-content">
                            <h3 style="margin: 10px 0 5px 0; color: #002244; font-size:1.2rem;"><?php echo htmlspecialchars($course['title']); ?></h3>
                            <p style="margin: 0 0 15px 0; color: #666; font-size: 0.9rem;">👤 المدرس: <?php echo htmlspecialchars($course['instructor_name']); ?></p>
                            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #eee; padding-top: 10px;">
                                <span style="font-weight: bold; color: #10b981; font-size: 1.2rem;"><?php echo ($course['price'] == 0) ? 'مجاني' : '$' . number_format($course['price'], 2); ?></span>
                                <a href="course-details.php?id=<?php echo $course['id']; ?>" class="btn-enroll" style="background-color: #003366; color: #fff; text-decoration: none; padding: 6px 12px; border-radius: 5px;">عرض الكورس</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align: center; color: #666; padding: 2rem; grid-column: 1/-1;">لا توجد كورسات منشورة حالياً.</p>
            <?php endif; ?>
        </div>
    </section>
</body>
</html>