<?php
include 'db.php';
session_start();

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error_message = "❌ يرجى كتابة البريد الإلكتروني وكلمة المرور.";
    } else {
        // جلب بيانات المستخدم بناءً على البريد الإلكتروني
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // التحقق من وجود الحساب وتطابق كلمة المرور المشفرة
        if ($user && password_verify($password, $user['password'])) {
            // تخزين بيانات المستخدم في الجلسة (Session)
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['fullname'];
            $_SESSION['user_role'] = $user['role']; // تخزين الرتبة (student أو instructor أو admin)

            // التوجيه الذكي الآمن حسب رتبة الحساب
            if ($_SESSION['user_role'] === 'admin') {
                header("Location: admin-dashboard.php"); // توجيه المدير العام إلى لوحته العليا
            } elseif ($_SESSION['user_role'] === 'instructor') {
                header("Location: dashboard.php"); // توجيه المدرس إلى لوحة التحكم الخاصة به
            } else {
                header("Location: index.php"); // توجيه الطالب إلى الصفحة الرئيسية لتصفح الكورسات
            }
            exit();
        } else {
            $error_message = "❌ البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول | المنصة التعليمية</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav class="lonk">
        <a href="index.php">الرئيسية</a>
        <a href="courses.php">معلومات الكورسات</a>
        <a href="contact.php">تواصل بنا</a>
        <a href="register.php" style="color: var(--primary-color);">إنشاء حساب جديد</a>
    </nav>

    <main class="auth-container">
        <div class="auth-box">
            <h2>تسجيل الدخول 🔑</h2>
            
            <?php if(!empty($error_message)): ?>
                <div style="background-color: #fee2e2; color: #b91c1c; padding: 12px; border-radius: 6px; margin-bottom: 1.25rem; text-align: center; font-weight: 500; font-size: 0.9rem; border: 1px solid #fca5a5;">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <form action="login.php" method="post">
                <div class="input-group">
                    <label>البريد الإلكتروني</label>
                    <input type="email" name="email" placeholder="example@mail.com" required autocomplete="email">
                </div>
                
                <div class="input-group">
                    <label>كلمة المرور</label>
                    <input type="password" name="password" placeholder="********" required autocomplete="current-password">
                </div>
                
                <button type="submit" class="btn-auth">دخول الحساب</button>
            </form>
            
            <p class="auth-footer">ليس لديك حساب على المنصة؟ <a href="register.php">سجل حساباً جديداً الآن</a></p>
        </div>
    </main>

</body>
</html>