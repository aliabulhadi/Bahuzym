<?php
include 'db.php';
session_start();

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$course_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'] ?? null;
$is_enrolled = false;

// جلب تفاصيل الكورس
$stmt_course = $pdo->prepare("SELECT c.*, u.fullname as instructor_name FROM courses c JOIN users u ON c.instructor_id = u.id WHERE c.id = ? AND c.status = 'published'");
$stmt_course->execute([$course_id]);
$course = $stmt_course->fetch();

if (!$course) { die("❌ هذا الكورس غير متاح."); }

// فحص الاشتراك
if ($user_id) {
    $stmt_check = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
    $stmt_check->execute([$user_id, $course_id]);
    if ($stmt_check->rowCount() > 0) { $is_enrolled = true; }
    if ($_SESSION['user_role'] === 'instructor' && $course['instructor_id'] == $user_id) { $is_enrolled = true; }
}

$stmt_lectures = $pdo->prepare("SELECT * FROM lectures WHERE course_id = ? ORDER BY order_number ASC");
$stmt_lectures->execute([$course_id]);
$lectures = $stmt_lectures->fetchAll();

$current_video = !empty($lectures) ? $lectures[0]['video_url'] : '';
$current_lecture_title = !empty($lectures) ? $lectures[0]['title'] : 'لا توجد دروس بعد';

if (isset($_GET['lecture_id'])) {
    $lecture_id = intval($_GET['lecture_id']);
    $stmt_sel = $pdo->prepare("SELECT * FROM lectures WHERE id = ? AND course_id = ?");
    $stmt_sel->execute([$lecture_id, $course_id]);
    $selected = $stmt_sel->fetch();
    if ($selected) {
        if ($selected['order_number'] == 1 || $is_enrolled) {
            $current_video = $selected['video_url'];
            $current_lecture_title = $selected['title'];
        } else {
            $error_permission = "🔒 هذا الدرس مغلق! يجب الاشتراك في الكورس أولاً.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تفاصيل الكورس</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="courses-container" style="display: flex; gap: 2rem; margin-top: 2rem; max-width:1200px; margin:2rem auto; padding:0 1rem;">
        <section style="flex-grow: 2;">
            <?php if (isset($error_permission)): ?>
                <div style="background:#fee2e2; color:#b91c1c; padding:12px; border-radius:8px; margin-bottom:1rem; font-weight:bold;"><?php echo $error_permission; ?></div>
            <?php endif; ?>
            
            <div style="background:#000; border-radius:12px; overflow:hidden;">
                <?php if (!empty($current_video)): ?>
                    <video src="<?php echo htmlspecialchars($current_video); ?>" controls controlsList="nodownload" style="width:100%; max-height:480px; display:block;"></video>
                <?php else: ?>
                    <div style="color:#fff; text-align:center; padding:5rem;">🎬 لا توجد فيديوهات مرفوعة.</div>
                <?php endif; ?>
            </div>
            <h2><?php echo htmlspecialchars($course['title']); ?></h2>
            <p>📖 الدرس الحالي: <strong style="color:#0055a5;"><?php echo htmlspecialchars($current_lecture_title); ?></strong></p>
            <div style="background:#fff; padding:1.5rem; border-radius:10px; margin-top:1rem; white-space: pre-line;"><?php echo htmlspecialchars($course['description']); ?></div>
        </section>

        <aside style="width:320px; background:#f8fafc; padding:1.5rem; border-radius:12px; border:1px solid #e2e8f0; height:fit-content;">
            <div style="text-align:center; margin-bottom:1.5rem;">
                <span style="color:#666;">سعر الدورة:</span>
                <strong style="font-size:2rem; color:#10b981; display:block; margin:0.5rem 0;"><?php echo ($course['price'] == 0) ? 'مجاني' : '$' . number_format($course['price'], 2); ?></strong>
                
                <?php if ($is_enrolled): ?>
                    <div style="background:#d1fae5; color:#065f46; padding:10px; border-radius:8px; font-weight:bold;">✓ أنت مشترك بالدورة</div>
                <?php else: ?>
                    <form action="enroll.php" method="post">
                        <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                        <button type="submit" class="btn-filter" style="background:#10b981; margin:0; width:100%;">🎯 اشترك الآن وابدأ التعلم</button>
                    </form>
                <?php endif; ?>
            </div>
            
            <h3>محتوى المنهج (<?php echo count($lectures); ?> درس)</h3>
            <div style="display:flex; flex-direction:column; gap:0.5rem;">
                <?php foreach ($lectures as $index => $lec): ?>
                    <?php $is_locked = ($lec['order_number'] > 1 && !$is_enrolled); ?>
                    <a href="course-details.php?id=<?php echo $course_id; ?>&lecture_id=<?php echo $lec['id']; ?>" style="display:flex; justify-content:space-between; padding:10px; background:#fff; border-radius:6px; text-decoration:none; color:#333; border:1px solid #eef2f6;">
                        <span><?php echo ($index+1) . ". " . htmlspecialchars($lec['title']); ?></span>
                        <span><?php echo $is_locked ? '🔒' : '▶️'; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </aside>
    </main>
</body>
</html>