<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'instructor') {
    header("Location: login.php");
    exit();
}

$error_message = "";
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title       = trim($_POST['title']);
    $category    = $_POST['category'];
    $description = trim($_POST['description']);
    $price       = floatval($_POST['price']);
    $status      = ($_POST['status'] === 'publish') ? 'published' : 'draft';
    $instructor_id = $_SESSION['user_id'];
    $lecture_title = trim($_POST['lecture_title']);

    $covers_dir = 'uploads/covers/';
    $videos_dir = 'uploads/videos/';
    if (!is_dir($covers_dir)) mkdir($covers_dir, 0777, true);
    if (!is_dir($videos_dir)) mkdir($videos_dir, 0777, true);

    $allowed_cover_types = ['image/jpeg', 'image/png', 'image/webp'];
    $allowed_video_types = ['video/mp4', 'video/webm'];
    
    $max_cover_size = 2 * 1024 * 1024;
    $max_video_size = 50 * 1024 * 1024;

    $cover_file = $_FILES['cover_image'];
    $cover_mime = mime_content_type($cover_file['tmp_name']);

    if (!in_array($cover_mime, $allowed_cover_types) || $cover_file['size'] > $max_cover_size) {
        $error_message = "❌ خطأ في مواصفات صورة الغلاف (يجب أن تكون صور حقيقية وأقل من 2 ميجابايت).";
    }

    $video_file = $_FILES['lecture_video'];
    $video_mime = mime_content_type($video_file['tmp_name']);

    if (empty($error_message)) {
        if (!in_array($video_mime, $allowed_video_types) || $video_file['size'] > $max_video_size) {
            $error_message = "❌ خطأ في مواصفات الفيديو (يجب أن يكون بصيغة MP4/WebM وبحجم أقل من 50 ميجابايت).";
        }
    }

    if (empty($error_message)) {
        $cover_name = uniqid('cover_', true) . '.' . pathinfo($cover_file['name'], PATHINFO_EXTENSION);
        $video_name = uniqid('video_', true) . '.' . pathinfo($video_file['name'], PATHINFO_EXTENSION);

        $cover_target = $covers_dir . $cover_name;
        $video_target = $videos_dir . $video_name;

        if (move_uploaded_file($cover_file['tmp_name'], $cover_target) && move_uploaded_file($video_file['tmp_name'], $video_target)) {
            try {
                $pdo->beginTransaction();

                $course_stmt = $pdo->prepare("INSERT INTO courses (title, description, price, cover_image, status, instructor_id) VALUES (?, ?, ?, ?, ?, ?)");
                $course_stmt->execute([$title, $description, $price, $cover_target, $status, $instructor_id]);
                $course_id = $pdo->lastInsertId();

                $lecture_stmt = $pdo->prepare("INSERT INTO lectures (course_id, title, video_url, order_number) VALUES (?, ?, ?, 1)");
                $lecture_stmt->execute([$course_id, $lecture_title, $video_target]);

                $pdo->commit();
                $success_message = "🚀 تم رفع الكورس وتأمينه بنجاح!";
            } catch (Exception $e) {
                $pdo->rollBack();
                if(file_exists($cover_target)) unlink($cover_target);
                if(file_exists($video_target)) unlink($video_target);
                $error_message = "خطأ قاعدة بيانات: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>رفع كورس جديد</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">
    <div class="dashboard-wrapper">
        <main class="dashboard-content" style="margin: 2rem auto; max-width:800px;">
            <h2>➕ إنشاء مساق تعليمي وتأمين ملفاته</h2>
            <?php if(!empty($error_message)): ?><div style="background:#fee2e2; color:#b91c1c; padding:10px; border-radius:5px;"><?php echo $error_message; ?></div><?php endif; ?>
            <?php if(!empty($success_message)): ?><div style="background:#d1fae5; color:#065f46; padding:10px; border-radius:5px;"><?php echo $success_message; ?></div><?php endif; ?>
            
            <form action="add-course.php" method="post" enctype="multipart/form-data" style="background:#fff; padding:2rem; border-radius:10px; margin-top:1rem;">
                <div class="input-group"><label>عنوان الكورس</label><input type="text" name="title" required></div>
                <div class="input-group"><label>المجال</label><select name="category"><option value="programming">برمجة</option><option value="design">تصميم</option></select></div>
                <div class="input-group"><label>الوصف</label><textarea name="description" rows="4" required></textarea></div>
                <div class="input-group"><label>السعر ($)</label><input type="number" name="price" step="0.01" required></div>
                <div class="input-group"><label>صورة الغلاف</label><input type="file" name="cover_image" required></div>
                <hr style="margin:2rem 0; border:0; border-top:1px solid #eee;">
                <h3>🎬 بيانات المحاضرة الترحيبية (الدرس الأول مجاني)</h3>
                <div class="input-group"><label>عنوان الدرس الأول</label><input type="text" name="lecture_title" placeholder="مثال: مقدمة ومدخل للمساق" required></div>
                <div class="input-group"><label>فيديو الدرس (MP4)</label><input type="file" name="lecture_video" required></div>
                <button type="submit" name="status" value="publish" class="btn-add-course">🚀 نشر الكورس الآن</button>
            </form>
        </main>
    </div>
</body>
</html>