-- ==========================================================================
-- 1. إنشاء قاعدة البيانات وتحديد الترميز الشامل يدعم اللغة العربية
-- ==========================================================================
CREATE DATABASE IF NOT EXISTS `lms_marketplace` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `lms_marketplace`;

-- ==========================================================================
-- 2. جدول المستخدمين (Users): يشمل الطلاب، المدرسين، والمدير العام
-- ==========================================================================
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(150) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('student', 'instructor', 'admin') NOT NULL DEFAULT 'student',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================================
-- 3. جدول الكورسات (Courses): يحتوي على بيانات المساقات والمدرس المالك لها
-- ==========================================================================
CREATE TABLE IF NOT EXISTS `courses` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `instructor_id` INT NOT NULL,
    `title` VARCHAR(205) NOT NULL,
    `category` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `cover_image` VARCHAR(255) NOT NULL,
    `status` ENUM('draft', 'published') NOT NULL DEFAULT 'draft',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`instructor_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================================
-- 4. جدول المحاضرات والدروس (Lectures): مرتبط بالكورسات ويدعم ترتيب الفيديوهات
-- ==========================================================================
CREATE TABLE IF NOT EXISTS `lectures` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `course_id` INT NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `video_url` VARCHAR(255) NOT NULL,
    `order_number` INT NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================================
-- 5. جدول الاشتراكات والمبيعات (Enrollments): يربط الطلاب بالكورسات ويسجل ماليّاً
-- ==========================================================================
CREATE TABLE IF NOT EXISTS `enrollments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `course_id` INT NOT NULL,
    `price_paid` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `enrolled_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================================
-- 6. جدول رسائل تواصل بنا (Contact Messages): يستقبل استفسارات الزوار للإدارة
-- ==========================================================================
CREATE TABLE IF NOT EXISTS `contact_messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(150) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `subject` VARCHAR(200) NOT NULL,
    `message` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================================
-- 7. زرع حساب مدير عام (Admin) تجريبي لغرض الفحص الأول للمنصة
-- البيانات: البريد (admin@lms.com) | كلمة المرور المشفرة الافتراضية هي: admin123
-- ==========================================================================
INSERT INTO `users` (`fullname`, `email`, `password`, `role`) 
VALUES (
    'المدير العام للمنصة', 
    'admin@gmail.com', 
    'admin', 
    'admin'
) ON DUPLICATE KEY UPDATE `id`=`id`;