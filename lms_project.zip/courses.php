<?php
include 'db.php';
session_start();

$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? trim($_GET['category']) : '';

$sql = "SELECT c.id, c.title, c.description, c.price, c.cover_image, u.fullname as instructor_name 
        FROM courses c 
        JOIN users u ON c.instructor_id = u.id 
        WHERE c.status = 'published'";
$params = [];

if (!empty($search_query)) {
    $sql .= " AND c.title LIKE ? ";
    $params[] = '%' . $search_query . '%';
}
if (!empty($category_filter)) {
    $sql .= " AND c.category = ? ";
    $params[] = $category_filter;
}
$sql .= " ORDER BY c.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$all_courses = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تصفح الكورسات</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <p class="brand-name">منصتنا التعليمية</p>
        <h1>تعلم مهارات المستقبل اليوم</h1>
        <h3>أكتشف الاف الكورسات التي يقدمها أفضل الخبراء في مجالات البرمجة و التصميم و أدارة الأعمال</h3>
    </header>
    <nav class="lonk">
        <a href="index.php">الرئيسية</a>
        <a href="courses.php">معلومات الكورسات</a>
        <a href="contact.php">تواصل بنا</a>
        <a href="about.php">من نحن</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="logout.php" style="color: #ef4444;">تسجيل الخروج</a>
        <?php else: ?>
            <a href="login.php">صفحة التسجيل</a>
        <?php endif; ?>
    </nav>

    <main class="courses-container" style="max-width: 1200px; margin: 3rem auto; padding: 0 1rem; display: flex; gap: 2rem;">
        <aside class="filters-sidebar" style="width: 280px; background: #fff; padding: 1.5rem; border-radius: 12px; height: fit-content;">
            <h3>تصفية النتائج 🔍</h3>
            <form action="courses.php" method="get" style="display: flex; flex-direction: column; gap: 1.2rem;">
                <div class="input-group">
                    <label>ابحث باسم الكورس:</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="اكتب كلمة...">
                </div>
                <div class="input-group">
                    <label>حسب المجال:</label>
                    <select name="category">
                        <option value="">كل المجالات</option>
                        <option value="programming" <?php echo ($category_filter === 'programming') ? 'selected' : ''; ?>>برمجة وتطوير الويب</option>
                        <option value="design" <?php echo ($category_filter === 'design') ? 'selected' : ''; ?>>تصميم وجرافيك</option>
                    </select>
                </div>
                <button type="submit" class="btn-filter" style="background:#0055a5; margin:0;">تطبيق الفلتر</button>
                <?php if(!empty($search_query) || !empty($category_filter)): ?>
                    <a href="courses.php" style="text-align: center; color: #ef4444; font-weight: bold; text-decoration:none;">✕ إعادة تعيين</a>
                <?php endif; ?>
            </form>
        </aside>

        <section class="courses-results" style="flex-grow: 1;">
            <div class="cont" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem;">
                <?php if (count($all_courses) > 0): ?>
                    <?php foreach ($all_courses as $course): ?>
                        <article class="course-card">
                            <img src="<?php echo htmlspecialchars($course['cover_image']); ?>" style="width: 100%; height: 160px; object-fit: cover; border-radius:10px 10px 0 0;">
                            <div class="course-content">
                                <h3 style="color:#002244; font-size:1.1rem;"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <p style="color:#666; font-size:0.85rem;">👤 المدرس: <?php echo htmlspecialchars($course['instructor_name']); ?></p>
                                <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #eee; padding-top: 10px;">
                                    <span style="font-weight: bold; color: #10b981;">$<?php echo number_format($course['price'], 2); ?></span>
                                    <a href="course-details.php?id=<?php echo $course['id']; ?>" class="btn-enroll" style="background:#003366; color:#fff; text-decoration:none; padding:5px 10px; border-radius:5px;">تفاصيل الكورس</a>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="grid-column: 1/-1; text-align: center; color:#666;">🔍 لم نجد أي نتائج تطابق بحثك.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>
</body>
</html>