<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['user_name'];

try {
    $stmt = $pdo->prepare("
        SELECT c.id, c.title, c.cover_image, u.fullname as instructor_name 
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        JOIN users u ON c.instructor_id = u.id
        WHERE e.student_id = ? ORDER BY e.enrolled_at DESC
    ");
    $stmt->execute([$student_id]);
    $my_courses = $stmt->fetchAll();
} catch (Exception $e) {
    die("حدث خطأ: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ملفي الشخصي الدراسي</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">
    <header class="header">
        <p class="brand-name">منصتنا التعليمية</p>
        <h1>تعلم مهارات المستقبل اليوم</h1>
        <h3>أكتشف الاف الكورسات التي يقدمها أفضل الخبراء في مجالات البرمجة و التصميم و أدارة الأعمال</h3>
    </header>
    <nav class="lonk">
        <a href="index.php">الرئيسية</a>
        <a href="courses.php">معلومات الكورسات</a>
        <a href="contact.php">تواصل بنا</a>
        <a href="profile.php" style="color:#0095ff; font-weight:bold;">👤 حسابي</a>
        <a href="logout.php" style="color:#ef4444;">تسجيل الخروج</a>
    </nav>

    <main style="max-width: 1100px; margin: 3rem auto; padding:0 1rem;">
        <header style="background:#002244; color:#fff; padding:2rem; border-radius:15px; text-align:center; margin-bottom:2rem;">
            <h2>🎓 مرحباً بك، <?php echo htmlspecialchars($student_name); ?></h2>
            <p>تابع دروسك ومحاضراتك المفتوحة من هنا.</p>
        </header>

        <section>
            <h3 style="border-right:5px solid #0055a5; padding-right:10px;">لوحة دروسي الحالية 📚</h3>
            <div class="cont" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap:1.5rem; margin-top:1.5rem;">
                <?php if (count($my_courses) > 0): ?>
                    <?php foreach ($my_courses as $course): ?>
                        <article class="course-card" style="background:#fff; border-radius:10px; overflow:hidden; box-shadow:0 4px 6px rgba(0,0,0,0.02);">
                            <img src="<?php echo htmlspecialchars($course['cover_image']); ?>" style="width:100%; height:150px; object-fit:cover;">
                            <div style="padding:1rem;">
                                <h4 style="color:#002244; margin:0 0 10px 0;"><?php echo htmlspecialchars($course['title']); ?></h4>
                                <p style="color:#666; font-size:0.85rem; margin-bottom:15px;">👤 المدرس: <?php echo htmlspecialchars($course['instructor_name']); ?></p>
                                <a href="course-details.php?id=<?php echo $course['id']; ?>" class="btn-enroll" style="background:#0055a5; color:#fff; text-decoration:none; padding:6px 12px; border-radius:5px; display:inline-block; font-size:0.9rem;">▶ متابعة التعلم</a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="grid-column:1/-1; text-align:center; color:#666; padding:3rem; background:#fff; border-radius:10px;">لم تشترك في أي كورس حتى الآن. <a href="courses.php">تصفح الكورسات من هنا</a></p>
                <?php endif; ?>
            </div>
        </section>
    </main>
</body>
</html>